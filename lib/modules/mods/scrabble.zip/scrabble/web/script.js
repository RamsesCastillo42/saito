
 $('.loader').hide();
 $('.main').css('display', 'all');

