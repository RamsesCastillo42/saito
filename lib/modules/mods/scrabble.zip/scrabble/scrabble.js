var saito = require('../../../saito');
var Game = require('../../game');
var util = require('util');


//////////////////
// CONSTRUCTOR  //
//////////////////
function Scrabble(app) {

  if (!(this instanceof Scrabble)) { return new Scrabble(app); }

  Scrabble.super_.call(this);

  this.app             = app;

  this.name            = "Scrabble";
  this.browser_active  = 0;
  this.handlesEmail    = 1;
  this.emailAppName    = "Scrabble";

  //
  // this sets the ratio used for determining
  // the size of the original pieces
  //
  this.gameboardWidth  = 2766;

  this.moves           = [];
  this.letters         = this.returnLetters();

  return this;

}
module.exports = Scrabble;
util.inherits(Scrabble, Game);



Scrabble.prototype.scoreWord = function scoreWord(x,y,vertical) {

  let cont       = 1;
  let score      = 0;

  let reconstructed_word = "";

  //
  // first score the main word
  //
  if (vertical == 0) {

    let word_start = x;
    let word_end   = x;
    let word_bonus = 1;

    //
    // find start of word
    //
    while (word_start >= 1 && cont == 1) {
      let letter_pos = (word_start-1) + "_" + y;
      if (this.game.board[letter_pos].letter != undefined) {
	word_start--;
      } else {
	cont = 0;
      }
      if (word_start == 1) { cont = 0; }
    }

    cont = 1;

    while (word_end <= 15 && cont == 1) {
      let letter_pos = (word_end+1) + "_" + y;
      if (this.game.board[letter_pos].letter != undefined) {
	word_end++;
      } else {
	cont = 0;
      }
      if (word_end == 15) { cont = 0; }
    }

    //
    // score word
    //
    let pos = "";
    let bonus = 1;
    let letter = "";
    let letter_score = "";

    for (let i = word_start; i <= word_end; i++) {

      pos = i + "_" + y;
      bonus = this.game.board[pos].bonus;
      letter = this.game.board[pos].letter.toLowerCase();
      letter_score = this.letters[letter].score;

      reconstructed_word += letter;

      if (bonus === "2xL") { letter_score = letter_score * 2; }
      if (bonus === "3xL") { letter_score = letter_score * 3; }
      if (bonus === "2xW") { word_bonus   = word_bonus * 2; }
      if (bonus === "3xW") { word_bonus   = word_bonus * 3; }

      score += letter_score;

      if (i == word_end) { score = score * word_bonus; } 

    }

    //
    // score each ancillary word
    //
    for (let d = word_start; d <= word_end; d++) {

      let pos = d + "_" + y;

      //
      // they also score vertical
      //
      if (this.game.board[pos].new == 1) {

	let vertical_word_start = y;
	let vertical_word_end   = y;

	cont = 1;

	//
    	// find start of word
    	//
    	while (vertical_word_start >= 1 && cont == 1) {
          vertical_letter_pos = d + "_" + (vertical_word_start-1);
          if (this.game.board[vertical_letter_pos].letter != undefined) {
            vertical_word_start--;
          } else {
            cont = 0;
          }
          if (vertical_word_start == 1) { cont = 0; }
        }

        cont = 1;

        while (vertical_word_end <= 15 && cont == 1) {
          vertical_letter_pos = d + "_" + (vertical_word_end+1);
          if (this.game.board[vertical_letter_pos].letter != undefined) {
            vertical_word_end++;
          } else {
            cont = 0;
          }
          if (word_end == 15) { cont = 0; }
        }

	//
	// we now have the start and end of the word
	//
	if (vertical_word_end != vertical_word_start) {
          for (let zz = vertical_word_start; zz <= vertical_word_end; zz++) {

            pos = d + "_" + zz;
            bonus = this.game.board[pos].bonus;
            letter = this.game.board[pos].letter.toLowerCase();
            letter_score = this.letters[letter].score;

            if (bonus === "2xL") { letter_score = letter_score * 2; }
            if (bonus === "3xL") { letter_score = letter_score * 3; }
            if (bonus === "2xW") { word_bonus   = word_bonus * 2; }
            if (bonus === "3xW") { word_bonus   = word_bonus * 3; }

            score += letter_score;

            if (zz == vertical_word_end) { score = score * word_bonus; } 

          }
        } 
      }
    }

    //
    // set all board bonuses to zero
    //
    for (let d = word_start; d <= word_end; d++) {
      let pos = d + "_" + y;
      this.game.board[pos].bonus = "";
      this.game.board[pos].new   = 0;
    }

  }











  //
  // first score the main word
  //
  if (vertical == 1) {

    let word_start = y;
    let word_end   = y;
    let word_bonus = 1;

    //
    // find start of word
    //
    while (word_start >= 1 && cont == 1) {
      let letter_pos = x + "_" + (word_start-1);
      if (this.game.board[letter_pos].letter != undefined) {
	word_start--;
      } else {
	cont = 0;
      }
      if (word_start == 1) { cont = 0; }
    }

    cont = 1;

    while (word_end <= 15 && cont == 1) {
      let letter_pos = x + "_" + (word_end+1);
      if (this.game.board[letter_pos].letter != undefined) {
	word_end++;
      } else {
	cont = 0;
      }
      if (word_end == 15) { cont = 0; }
    }

    //
    // score word
    //
    let pos = "";
    let bonus = 1;
    let letter = "";
    let letter_score = "";

    for (let i = word_start; i <= word_end; i++) {

      pos = x + "_" + i;
      bonus = this.game.board[pos].bonus;
      letter = this.game.board[pos].letter.toLowerCase();
      letter_score = this.letters[letter].score;

      reconstructed_word += letter;

      if (bonus === "2xL") { letter_score = letter_score * 2; }
      if (bonus === "3xL") { letter_score = letter_score * 3; }
      if (bonus === "2xW") { word_bonus   = word_bonus * 2; }
      if (bonus === "3xW") { word_bonus   = word_bonus * 3; }

      score += letter_score;

      if (i == word_end) { score = score * word_bonus; } 

    }

    //
    // score each ancillary word
    //
    for (let d = word_start; d <= word_end; d++) {

      let pos = x + "_" + d;

      //
      // they also score vertical
      //
      if (this.game.board[pos].new == 1) {

	let vertical_word_start = y;
	let vertical_word_end   = y;

	cont = 1;

	//
    	// find start of word
    	//
    	while (vertical_word_start >= 1 && cont == 1) {
          vertical_letter_pos = (vertical_word_start-1) + "_" + d
          if (this.game.board[vertical_letter_pos].letter != undefined) {
            vertical_word_start--;
          } else {
            cont = 0;
          }
          if (vertical_word_start == 1) { cont = 0; }
        }

        cont = 1;

        while (vertical_word_end <= 15 && cont == 1) {
          vertical_letter_pos = (vertical_word_end+1) + "_" + d;
          if (this.game.board[vertical_letter_pos].letter != undefined) {
            vertical_word_end++;
          } else {
            cont = 0;
          }
          if (word_end == 15) { cont = 0; }
        }

	//
	// we now have the start and end of the word
	//
	if (vertical_word_end != vertical_word_start) {
          for (let zz = vertical_word_start; zz <= vertical_word_end; zz++) {

            pos = d + "_" + zz;
            bonus = this.game.board[pos].bonus;
            letter = this.game.board[pos].letter.toLowerCase();
            letter_score = this.letters[letter].score;

            if (bonus === "2xL") { letter_score = letter_score * 2; }
            if (bonus === "3xL") { letter_score = letter_score * 3; }
            if (bonus === "2xW") { word_bonus   = word_bonus * 2; }
            if (bonus === "3xW") { word_bonus   = word_bonus * 3; }

            score += letter_score;

            if (zz == vertical_word_end) { score = score * word_bonus; } 

          }
        } 
      }
    }

    //
    // set all board bonuses to zero
    //
    for (let d = word_start; d <= word_end; d++) {
      let pos = d + "_" + y;
      this.game.board[pos].bonus = "";
      this.game.board[pos].new   = 0;
    }
 
  }





  return score;

}








////////////////
// initialize //
////////////////
Scrabble.prototype.initializeGame = async function initializeGame(game_id) {

  this.updateStatus("loading game...");
  this.loadGame(game_id);

  if (this.game.status != "") { this.updateStatus(this.game.status); }

  this.game.board = this.returnBoard();

  //
  // initialize board placement
  //
  for (let i = 1; i < 16; i++) {
    for (let j = 1; j < 16; j++) {
      let z = i + "_" + j;
      let x = "#" + i + "_" + j;
      let h = ((i-1) * 177) + 85;
      let w = ((j-1) * 190) + 100;
      $(x).css('top',this.scale(w));
      $(x).css('left',this.scale(h));
      $(x).css('width',this.scale(148));
      $(x).css('height',this.scale(163));
      if (this.game.board[z].letter != undefined) {
	this.placeLetter(this.game.board[z].letter, i, j);
	this.game.board[z].new = 0;
      }
    }
  }

  //
  // initialize bonuses
  //
  if (this.game.board["1_1"].letter == undefined) { this.game.board["1_1"].bonus = "3xW"; }
  if (this.game.board["1_1"].letter == undefined) { this.game.board["1_1"].bonus = "2xL"; }
  if (this.game.board["1_8"].letter == undefined) { this.game.board["1_8"].bonus = "3xW"; }
  if (this.game.board["1_1"].letter == undefined) { this.game.board["1_1"].bonus = "2xL"; }
  if (this.game.board["1_15"].letter == undefined) { this.game.board["1_15"].bonus = "3xW"; }

  if (this.game.board["2_2"].letter == undefined) { this.game.board["2_2"].bonus = "2xW"; }
  if (this.game.board["2_6"].letter == undefined) { this.game.board["2_6"].bonus = "3xL"; }
  if (this.game.board["2_10"].letter == undefined) { this.game.board["2_10"].bonus = "3xL"; }
  if (this.game.board["2_14"].letter == undefined) { this.game.board["2_14"].bonus = "2xW"; }

  if (this.game.board["3_3"].letter == undefined) { this.game.board["3_3"].bonus = "2xW"; }
  if (this.game.board["3_7"].letter == undefined) { this.game.board["3_7"].bonus = "2xL"; }
  if (this.game.board["3_9"].letter == undefined) { this.game.board["3_9"].bonus = "2xL"; }
  if (this.game.board["3_13"].letter == undefined) { this.game.board["3_13"].bonus = "2xW"; }

  if (this.game.board["4_1"].letter == undefined) { this.game.board["4_1"].bonus = "2xL"; }
  if (this.game.board["4_4"].letter == undefined) { this.game.board["4_4"].bonus = "3xL"; }
  if (this.game.board["4_8"].letter == undefined) { this.game.board["4_8"].bonus = "2xL"; }
  if (this.game.board["4_12"].letter == undefined) { this.game.board["4_12"].bonus = "3xL"; }
  if (this.game.board["4_15"].letter == undefined) { this.game.board["4_15"].bonus = "2xL"; }

  if (this.game.board["5_5"].letter == undefined) { this.game.board["5_5"].bonus = "2xW"; }
  if (this.game.board["5_11"].letter == undefined) { this.game.board["5_11"].bonus = "2xW"; }

  if (this.game.board["6_2"].letter == undefined) { this.game.board["6_2"].bonus = "2xW"; }
  if (this.game.board["6_6"].letter == undefined) { this.game.board["6_6"].bonus = "3xL"; }
  if (this.game.board["6_10"].letter == undefined) { this.game.board["6_10"].bonus = "3xL"; }
  if (this.game.board["6_14"].letter == undefined) { this.game.board["6_14"].bonus = "2xW"; }

  if (this.game.board["7_3"].letter == undefined) { this.game.board["7_3"].bonus = "3xL"; }
  if (this.game.board["7_7"].letter == undefined) { this.game.board["7_7"].bonus = "3xL"; }
  if (this.game.board["7_9"].letter == undefined) { this.game.board["7_9"].bonus = "3xL"; }
  if (this.game.board["7_13"].letter == undefined) { this.game.board["7_13"].bonus = "3xL"; }

  if (this.game.board["8_1"].letter == undefined) { this.game.board["8_1"].bonus = "3xW"; }
  if (this.game.board["8_4"].letter == undefined) { this.game.board["8_4"].bonus = "2xL"; }
  if (this.game.board["8_12"].letter == undefined) { this.game.board["8_12"].bonus = "2xL"; }
  if (this.game.board["8_15"].letter == undefined) { this.game.board["8_15"].bonus = "3xW"; }

  if (this.game.board["9_3"].letter == undefined) { this.game.board["9_3"].bonus = "3xL"; }
  if (this.game.board["9_7"].letter == undefined) { this.game.board["9_7"].bonus = "3xL"; }
  if (this.game.board["9_9"].letter == undefined) { this.game.board["9_9"].bonus = "3xL"; }
  if (this.game.board["9_13"].letter == undefined) { this.game.board["9_13"].bonus = "3xL"; }

  if (this.game.board["10_2"].letter == undefined) { this.game.board["10_2"].bonus = "3xL"; }
  if (this.game.board["10_6"].letter == undefined) { this.game.board["10_6"].bonus = "3xL"; }
  if (this.game.board["10_10"].letter == undefined) { this.game.board["10_10"].bonus = "3xL"; }
  if (this.game.board["10_14"].letter == undefined) { this.game.board["10_14"].bonus = "3xL"; }

  if (this.game.board["11_5"].letter == undefined) { this.game.board["11_5"].bonus = "2xW"; }
  if (this.game.board["11_11"].letter == undefined) { this.game.board["11_11"].bonus = "2xW"; }

  if (this.game.board["12_1"].letter == undefined) { this.game.board["12_1"].bonus = "2xL"; }
  if (this.game.board["12_4"].letter == undefined) { this.game.board["12_4"].bonus = "3xL"; }
  if (this.game.board["12_8"].letter == undefined) { this.game.board["12_8"].bonus = "2xL"; }
  if (this.game.board["12_12"].letter == undefined) { this.game.board["12_12"].bonus = "3xL"; }
  if (this.game.board["12_15"].letter == undefined) { this.game.board["12_15"].bonus = "2xL"; }

  if (this.game.board["13_3"].letter == undefined) { this.game.board["13_3"].bonus = "2xW"; }
  if (this.game.board["13_7"].letter == undefined) { this.game.board["13_7"].bonus = "3xL"; }
  if (this.game.board["13_9"].letter == undefined) { this.game.board["13_9"].bonus = "3xL"; }
  if (this.game.board["13_13"].letter == undefined) { this.game.board["13_13"].bonus = "2xW"; }

  if (this.game.board["14_2"].letter == undefined) { this.game.board["14_2"].bonus = "2xW"; }
  if (this.game.board["14_6"].letter == undefined) { this.game.board["14_6"].bonus = "3xL"; }
  if (this.game.board["14_10"].letter == undefined) { this.game.board["14_10"].bonus = "3xL"; }
  if (this.game.board["14_14"].letter == undefined) { this.game.board["14_14"].bonus = "2xW"; }

  if (this.game.board["15_1"].letter == undefined) { this.game.board["15_1"].bonus = "3xW"; }
  if (this.game.board["15_4"].letter == undefined) { this.game.board["15_4"].bonus = "2xL"; }
  if (this.game.board["15_8"].letter == undefined) { this.game.board["15_8"].bonus = "3xW"; }
  if (this.game.board["15_12"].letter == undefined) { this.game.board["15_12"].bonus = "2xL"; }
  if (this.game.board["15_15"].letter == undefined) { this.game.board["15_15"].bonus = "3xW"; }





  //
  // shift to game choices 
  //
  if (this.browser_active == 1) {
    let msg = {};
    msg.extra = {};
    msg.extra.target = this.game.target;
    this.handleGame(msg);
  }

}



Scrabble.prototype.playerTurn = function playerTurn() {

  let scrabble_self = this;

  for (let i = 1; i < 16; i++) {
    for (let j = 1; j < 16; j++) {

      let x = "#" + i + "_" + j;

      $(x).off();
      $(x).on('click', function() {

	let starting_box = $(this).attr('id');
	$('.status').css('display','block');

        $('.status').html('Place word <span class="option" id="vertical">VERTICALLY</span> or <div class="option" id="horizontal">HORIZONTALLY</div>.');

	$('.option').off();
	$('.option').on('click', function() {

	  let choice = $(this).attr('id');
          let word = prompt("Please enter your word");
	      word = word.toUpperCase();
	  let tmp  = starting_box.split("_");
	  let x    = parseInt(tmp[0]);
	  let y    = parseInt(tmp[1]);
	  let z    = 0;

	  if (choice == "vertical") {
	    z = 1;
	    for (let a = 0; a < word.length; a++) {
	      scrabble_self.placeLetter(word[a], x, (y+a));
	    }
	  }

	  if (choice == "horizontal") {
	    for (let a = 0; a < word.length; a++) {
	      scrabble_self.placeLetter(word[a], (x+a), y);
	    }
	  }

	  // add up points
	  let points = scrabble_self.scoreWord(x,y,z);

	  $('.status').css('display','none');


	});
      });
    }
  }
}




Scrabble.prototype.placeLetter = function placeLetter(letter, x, y) {

  let j = x + "_" + y;
  let i = "#" + j;

  let html = '';

  if (letter == "A") { html = '<img src="/scrabble/images/01_A.png" style="letter" />' }
  if (letter == "B") { html = '<img src="/scrabble/images/02_B.png" style="letter" />' }
  if (letter == "C") { html = '<img src="/scrabble/images/03_C.png" style="letter" />' }
  if (letter == "D") { html = '<img src="/scrabble/images/04_D.png" style="letter" />' }
  if (letter == "E") { html = '<img src="/scrabble/images/05_E.png" style="letter" />' }
  if (letter == "F") { html = '<img src="/scrabble/images/06_F.png" style="letter" />' }
  if (letter == "G") { html = '<img src="/scrabble/images/07_G.png" style="letter" />' }
  if (letter == "H") { html = '<img src="/scrabble/images/08_H.png" style="letter" />' }
  if (letter == "I") { html = '<img src="/scrabble/images/09_I.png" style="letter" />' }
  if (letter == "J") { html = '<img src="/scrabble/images/10_J.png" style="letter" />' }
  if (letter == "K") { html = '<img src="/scrabble/images/11_K.png" style="letter" />' }
  if (letter == "L") { html = '<img src="/scrabble/images/12_L.png" style="letter" />' }
  if (letter == "M") { html = '<img src="/scrabble/images/13_M.png" style="letter" />' }
  if (letter == "N") { html = '<img src="/scrabble/images/14_N.png" style="letter" />' }
  if (letter == "O") { html = '<img src="/scrabble/images/15_O.png" style="letter" />' }
  if (letter == "P") { html = '<img src="/scrabble/images/16_P.png" style="letter" />' }
  if (letter == "Q") { html = '<img src="/scrabble/images/17_Q.png" style="letter" />' }
  if (letter == "R") { html = '<img src="/scrabble/images/18_R.png" style="letter" />' }
  if (letter == "S") { html = '<img src="/scrabble/images/19_S.png" style="letter" />' }
  if (letter == "T") { html = '<img src="/scrabble/images/20_T.png" style="letter" />' }
  if (letter == "U") { html = '<img src="/scrabble/images/21_U.png" style="letter" />' }
  if (letter == "V") { html = '<img src="/scrabble/images/22_V.png" style="letter" />' }
  if (letter == "W") { html = '<img src="/scrabble/images/23_W.png" style="letter" />' }
  if (letter == "X") { html = '<img src="/scrabble/images/24_X.png" style="letter" />' }
  if (letter == "Y") { html = '<img src="/scrabble/images/25_Y.png" style="letter" />' }
  if (letter == "Z") { html = '<img src="/scrabble/images/26_Z.png" style="letter" />' }

  this.game.board[j].letter = letter;
  this.game.board[j].new    = 1;

  $(i).html(html);
  $(i).css('background-color','none');

  i = i + " > img";
  $(i).css('width',this.scale(148));
  $(i).css('height',this.scale(163));

  $(i).off();

}



//
// Core Game Logic
//
Scrabble.prototype.handleGame = function handleGame(msg=null) {

  //
  // update the board
  //


  //
  // let next player go
  //
  if (msg.extra.target == this.game.player) {
    this.playerTurn();
  }

}




Scrabble.prototype.returnLetters = function returnLetters() {

  var letters = {};

  letters['a'] = { score : 1 }
  letters['b'] = { score : 3 }
  letters['c'] = { score : 3 }
  letters['d'] = { score : 2 }
  letters['e'] = { score : 1 }
  letters['f'] = { score : 4 }
  letters['g'] = { score : 2 }
  letters['h'] = { score : 4 }
  letters['i'] = { score : 1 }
  letters['j'] = { score : 8 }
  letters['k'] = { score : 5 }
  letters['l'] = { score : 1 }
  letters['m'] = { score : 3 }
  letters['n'] = { score : 1 }
  letters['o'] = { score : 1 }
  letters['p'] = { score : 3 }
  letters['q'] = { score : 10 }
  letters['r'] = { score : 1 }
  letters['s'] = { score : 1 }
  letters['t'] = { score : 1 }
  letters['u'] = { score : 1 }
  letters['v'] = { score : 4 }
  letters['w'] = { score : 4 }
  letters['x'] = { score : 8 }
  letters['y'] = { score : 4 }
  letters['z'] = { score : 10 }

  return letters;

}
Scrabble.prototype.returnBoard = function returnBoard() {

  if (this.game.board == undefined) {
    this.game.board = {};
  }

  for (let i = 1; i < 16; i++) {
    for (let j = 1; j < 16; j++) {
      let x = i + "_" + j;
      if (this.game.board[x] == undefined) {
        this.game.board[x] = {};
      }
    }
  }

  return this.game.board;

}







////////////////////
// onConfirmation //
////////////////////
//
// all games should implement onConfirmation, checking if the transactions
// are intended for them and passing them to the transaction-handling 
// function of the inherited parent class as appropriate.
//
Scrabble.prototype.onConfirmation = async function onConfirmation(blk, tx, conf, app) {

  var twilight_self = app.modules.returnModule("Scrabble");
  var txmsg = tx.returnMessage();
  if (txmsg.module != "Scrabble") { return; } 
  twilight_self.handleOnConfirmation(blk, tx, conf, app, twilight_self);

}


///////////////
// webServer //
///////////////
Scrabble.prototype.webServer = function webServer(app, expressapp) {

  expressapp.get('/scrabble/', function (req, res) {
    res.sendFile(__dirname + '/web/index.html');
    return;
  });
  expressapp.get('/scrabble/style.css', function (req, res) {
    res.sendFile(__dirname + '/web/style.css');
    return;
  });
  expressapp.get('/scrabble/script.js', function (req, res) {
    res.sendFile(__dirname + '/web/script.js');
    return;

  });
  expressapp.get('/scrabble/images/:imagefile', function (req, res) {
    var imgf = '/web/images/'+req.params.imagefile;
    if (imgf.indexOf("\/") != false) { return; }
    res.sendFile(__dirname + imgf);
    return;
  });

}



